#include "WorldBase.hpp"
#include "GameManager.hpp"

WorldBase::WorldBase() {}

WorldBase::~WorldBase() {}
